﻿namespace ClassLibraryCallkulate;
public class Class1
{

}
